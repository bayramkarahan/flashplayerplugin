#!/bin/bash
sudo dpkg -r flashplayer
exit 0